<?php
require_once __DIR__ . '/header.php';

$db = get_db_connection();
if ($db && function_exists('ensure_contact_messages_table')) {
    ensure_contact_messages_table($db);
}

$msg = '';
$msg_type = 'success';

// Handle Actions: delete, mark_read, mark_unread
$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if ($action === 'delete' && $id > 0) {
    $stmt = $db->prepare("DELETE FROM contact_messages WHERE id = ?");
    if ($stmt->execute([$id])) {
        $msg = 'Message deleted successfully!';
    }
} elseif ($action === 'mark_read' && $id > 0) {
    $stmt = $db->prepare("UPDATE contact_messages SET is_read = 1 WHERE id = ?");
    $stmt->execute([$id]);
    $msg = 'Message marked as read.';
} elseif ($action === 'mark_unread' && $id > 0) {
    $stmt = $db->prepare("UPDATE contact_messages SET is_read = 0 WHERE id = ?");
    $stmt->execute([$id]);
    $msg = 'Message marked as unread.';
}

// Filters & Search
$filter = $_GET['filter'] ?? 'all';
$search = trim($_GET['search'] ?? '');

$query = "SELECT * FROM contact_messages WHERE 1=1";
$params = [];

if ($filter === 'unread') {
    $query .= " AND is_read = 0";
} elseif ($filter === 'read') {
    $query .= " AND is_read = 1";
}

if (!empty($search)) {
    $query .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ? OR subject LIKE ? OR message LIKE ?)";
    $s_term = "%$search%";
    $params = array_merge($params, [$s_term, $s_term, $s_term, $s_term, $s_term]);
}

$query .= " ORDER BY id DESC";
$stmt = $db->prepare($query);
$stmt->execute($params);
$messages = $stmt->fetchAll() ?: [];

// Get counts
$unread_count = (int)$db->query("SELECT COUNT(*) FROM contact_messages WHERE is_read = 0")->fetchColumn();
$total_count = (int)$db->query("SELECT COUNT(*) FROM contact_messages")->fetchColumn();
?>

<div class="container-fluid py-2">
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
        <div>
            <h3 class="fw-bold mb-1 text-danger"><i class="bi bi-envelope-paper-fill me-2"></i> Contact Messages & Form Inquiries</h3>
            <p class="text-muted small mb-0">Manage messages sent by visitors from the website contact page.</p>
        </div>
        <div class="d-flex gap-2">
            <span class="badge bg-danger fs-6 py-2 px-3 rounded-pill"><i class="bi bi-envelope-exclamation me-1"></i> <?= $unread_count ?> Unread Messages</span>
            <span class="badge bg-dark fs-6 py-2 px-3 rounded-pill"><i class="bi bi-inbox me-1"></i> <?= $total_count ?> Total</span>
        </div>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-<?= $msg_type ?> alert-dismissible fade show shadow-sm mb-4" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($msg) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filter & Search Bar -->
    <div class="card shadow-sm border-0 mb-4 bg-white rounded-3">
        <div class="card-body p-3">
            <form action="messages.php" method="GET" class="row g-2 align-items-center">
                <div class="col-md-5 d-flex gap-2">
                    <a href="messages.php?filter=all" class="btn btn-sm <?= $filter === 'all' ? 'btn-dark' : 'btn-outline-secondary' ?>">All (<?= $total_count ?>)</a>
                    <a href="messages.php?filter=unread" class="btn btn-sm <?= $filter === 'unread' ? 'btn-danger' : 'btn-outline-danger' ?>">Unread (<?= $unread_count ?>)</a>
                    <a href="messages.php?filter=read" class="btn btn-sm <?= $filter === 'read' ? 'btn-success' : 'btn-outline-success' ?>">Read</a>
                </div>
                <div class="col-md-7">
                    <div class="input-group input-group-sm">
                        <input type="text" name="search" class="form-control" placeholder="Search by sender name, email, phone, or message keywords..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-danger"><i class="bi bi-search me-1"></i> Search</button>
                        <?php if (!empty($search)): ?>
                            <a href="messages.php" class="btn btn-outline-secondary"><i class="bi bi-x-circle"></i> Clear</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Messages Table -->
    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 50px;" class="text-center">Status</th>
                            <th>Sender</th>
                            <th>Subject & Preview</th>
                            <th>Phone</th>
                            <th>Submitted Date</th>
                            <th class="text-end" style="width: 180px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($messages)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                                    No contact messages found.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($messages as $m): ?>
                                <tr class="<?= $m['is_read'] == 0 ? 'table-warning fw-bold' : '' ?>">
                                    <td class="text-center">
                                        <?php if ($m['is_read'] == 0): ?>
                                            <span class="badge bg-danger rounded-pill px-2 py-1" title="Unread"><i class="bi bi-envelope-fill"></i> New</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary rounded-pill px-2 py-1" title="Read"><i class="bi bi-envelope-open"></i> Read</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($m['name']) ?></div>
                                        <small class="text-muted"><i class="bi bi-envelope me-1"></i><?= htmlspecialchars($m['email']) ?></small>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-primary mb-1"><?= htmlspecialchars($m['subject']) ?></div>
                                        <div class="text-muted small text-truncate" style="max-width: 350px;">
                                            <?= htmlspecialchars(mb_strimwidth($m['message'], 0, 90, '...')) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($m['phone'])): ?>
                                            <a href="tel:<?= htmlspecialchars($m['phone']) ?>" class="text-decoration-none text-dark small"><i class="bi bi-telephone me-1 text-danger"></i><?= htmlspecialchars($m['phone']) ?></a>
                                        <?php else: ?>
                                            <span class="text-muted small">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small class="text-muted"><i class="bi bi-clock me-1"></i><?= date('M d, Y h:i A', strtotime($m['created_at'])) ?></small>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#viewMsgModal<?= $m['id'] ?>" title="View Message Details">
                                                <i class="bi bi-eye-fill"></i> Read
                                            </button>
                                            <a href="mailto:<?= htmlspecialchars($m['email']) ?>?subject=Re: <?= urlencode($m['subject']) ?>" class="btn btn-outline-success" title="Reply via Email">
                                                <i class="bi bi-reply-fill"></i>
                                            </a>
                                            <?php if ($m['is_read'] == 0): ?>
                                                <a href="messages.php?action=mark_read&id=<?= $m['id'] ?>" class="btn btn-outline-secondary" title="Mark as Read">
                                                    <i class="bi bi-check2-circle"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="messages.php?action=mark_unread&id=<?= $m['id'] ?>" class="btn btn-outline-warning" title="Mark as Unread">
                                                    <i class="bi bi-envelope"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="messages.php?action=delete&id=<?= $m['id'] ?>" class="btn btn-outline-danger" onclick="return confirm('Permanently delete this message?');" title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>

                                <!-- View Modal -->
                                <div class="modal fade" id="viewMsgModal<?= $m['id'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header bg-dark text-white">
                                                <h5 class="modal-title fw-bold"><i class="bi bi-envelope-paper me-2 text-danger"></i> Message from <?= htmlspecialchars($m['name']) ?></h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body p-4">
                                                <div class="row g-3 mb-3 border-bottom pb-3">
                                                    <div class="col-md-6">
                                                        <strong class="text-muted d-block small">Sender Name:</strong>
                                                        <span class="fs-6 fw-bold"><?= htmlspecialchars($m['name']) ?></span>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <strong class="text-muted d-block small">Email Address:</strong>
                                                        <a href="mailto:<?= htmlspecialchars($m['email']) ?>" class="fs-6 fw-bold text-danger text-decoration-none"><?= htmlspecialchars($m['email']) ?></a>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <strong class="text-muted d-block small">Phone Number:</strong>
                                                        <span class="fs-6"><?= !empty($m['phone']) ? htmlspecialchars($m['phone']) : 'N/A' ?></span>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <strong class="text-muted d-block small">Received Date:</strong>
                                                        <span class="fs-6 text-muted"><?= date('F j, Y \a\t g:i A', strtotime($m['created_at'])) ?></span>
                                                    </div>
                                                    <div class="col-12">
                                                        <strong class="text-muted d-block small">Subject:</strong>
                                                        <span class="fs-5 fw-bold text-primary"><?= htmlspecialchars($m['subject']) ?></span>
                                                    </div>
                                                </div>

                                                <strong class="text-muted d-block small mb-2">Message Body:</strong>
                                                <div class="p-3 bg-light border rounded text-dark fs-6" style="white-space: pre-wrap; line-height: 1.6;">
                                                    <?= htmlspecialchars($m['message']) ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer bg-light">
                                                <a href="messages.php?action=mark_read&id=<?= $m['id'] ?>" class="btn btn-outline-secondary btn-sm">Mark Read</a>
                                                <a href="mailto:<?= htmlspecialchars($m['email']) ?>?subject=Re: <?= urlencode($m['subject']) ?>" class="btn btn-success btn-sm fw-bold">
                                                    <i class="bi bi-reply-fill me-1"></i> Reply via Email
                                                </a>
                                                <button type="button" class="btn btn-dark btn-sm" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
